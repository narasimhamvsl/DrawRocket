package com.rocket.draw;

public class DrawRocket {

	public static void main(String[] args) {
		drawHead();
		drawBodyA();
		drawBodyB();
		stars();
		drawBodyB();
		drawBodyA();

		drawTail();

	}

	public static void drawHead() {
		// Drawing the rocket head

		for (int row = 0; row < 13; row++) {

			for (int space = 0; space < 13 - row; space++)
				System.out.print(' ');

			for (int sLash = 0; sLash <= row; sLash++)
				System.out.print('/');

			System.out.print("**");
			for (int sLash = 0; sLash <= row; sLash++)
				System.out.print('\\');
			System.out.println();
		}
		stars();
	}// draw head

	public static void drawTail() {
		// Drawing the rocket tail
		stars();
		for (int row = 0; row < 13; row++) {

			for (int space = 0; space < 13 - row; space++)
				System.out.print(' ');

			for (int sLash = 0; sLash <= row; sLash++)
				System.out.print('/');

			System.out.print("**");
			for (int sLash = 0; sLash <= row; sLash++)
				System.out.print('\\');
			System.out.println();

		}
	}// draw tail

	// Rocket Base
	public static void stars() {
		System.out.print("+");
		for (int stars = 0; stars < 14; stars++)
			System.out.print("=*");
		System.out.print("+");
		System.out.println();
	}

	// RocketBody PartA
	public static void drawBodyA() {
		for (int row = 0; row < 7; row++) {

			System.out.print("|");
			for (int dot = 0; dot < 7 - (row + 1); dot++) {
				System.out.print(".");
			}
			for (int arrow = 0; arrow < (row + 1); arrow++)
				System.out.print("/\\");

			for (int dot = 0; dot < 12 - (row * 2); dot++) {
				System.out.print(".");
			}
			for (int arrow = 0; arrow < (row + 1); arrow++)
				System.out.print("/\\");
			for (int dot = 0; dot < 7 - (row + 1); dot++) {
				System.out.print(".");
			}
			System.out.print("|");
			System.out.println();
		}
	}

	public static void drawBodyB() {
		for (int row = 0; row < 7; row++) {

			System.out.print("|");
			for (int dot = 7; dot > 7 - row; dot--) {
				System.out.print(".");
			}

			for (int arrow = 0; arrow < 7 - row; arrow++)
				System.out.print("\\/");
			for (int dot = 12; dot > 12 - (row * 2); dot--) {
				System.out.print(".");
			}
			for (int arrow = 0; arrow < 7 - row; arrow++)
				System.out.print("\\/");
			for (int dot = 7; dot > 7 - row; dot--) {
				System.out.print(".");
			}
			System.out.print("|");
			System.out.println();
		}
	}
}
